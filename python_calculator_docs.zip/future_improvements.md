# Future Improvements

## Add More Operations
- Modulus  
- Exponent  
- Square root  

## GUI Version
Using Tkinter or PyQt.

## Web Version
Using Flask, Django, or Streamlit.

## Voice Commands
Using speech recognition.

## Unit Testing
Using unittest or pytest.
